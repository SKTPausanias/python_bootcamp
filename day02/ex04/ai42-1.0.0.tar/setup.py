from setuptools import setup

setup(name='ai42',
	version='0.1',
	description='Testing installation of Package',
	url='#',
	license='MIT',
	packages=['ai42'],
	zip_safe=False)